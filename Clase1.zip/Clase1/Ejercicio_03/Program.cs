﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 3";
            Console.WriteLine("Ingrese Un Numero:");
            string aux = Console.ReadLine();
            int numero;
            int i;
            int j;
            bool bandera = true;


            if (int.TryParse(aux,out numero))
            {
                for(i=2;i<numero;i++)
                {
                    for(j=2;j<i;j++)
                    {
                        if(i % j == 0)
                        {
                            bandera = false;
                            break;
                        }
 
                    }
                    if (bandera)
                    {
                        Console.WriteLine("Numeros Primos:{0}", i);
                    }
                    else
                    {
                        bandera = true;

                    }
                }
                Console.ReadLine();
            }
        }
    }
}
