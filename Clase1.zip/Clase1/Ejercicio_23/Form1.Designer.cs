﻿namespace Ejercicio_23
{
    partial class Conversor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.BtnConvertEuro = new System.Windows.Forms.Button();
            this.BtnConverDolar = new System.Windows.Forms.Button();
            this.BtnConvertPesos = new System.Windows.Forms.Button();
            this.BtnCotizacion = new System.Windows.Forms.Button();
            this.txtEuro = new System.Windows.Forms.TextBox();
            this.txtDolar = new System.Windows.Forms.TextBox();
            this.txtPesos = new System.Windows.Forms.TextBox();
            this.txtEuroEuro = new System.Windows.Forms.TextBox();
            this.txtDolarEuro = new System.Windows.Forms.TextBox();
            this.txtPesosEuro = new System.Windows.Forms.TextBox();
            this.txtEuroDolar = new System.Windows.Forms.TextBox();
            this.txtDolarDolar = new System.Windows.Forms.TextBox();
            this.txtPesosDolar = new System.Windows.Forms.TextBox();
            this.txtEuroPesos = new System.Windows.Forms.TextBox();
            this.txtDolarPesos = new System.Windows.Forms.TextBox();
            this.txtPesosPesos = new System.Windows.Forms.TextBox();
            this.txtCotizacionEuro = new System.Windows.Forms.TextBox();
            this.txtCotizacionDolar = new System.Windows.Forms.TextBox();
            this.txtCotizacionPesos = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(99, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cotizacion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Euro";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(42, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Dolar";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Pesos";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(351, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Euro";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(488, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Dolar";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(618, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Pesos";
            // 
            // BtnConvertEuro
            // 
            this.BtnConvertEuro.Location = new System.Drawing.Point(226, 102);
            this.BtnConvertEuro.Name = "BtnConvertEuro";
            this.BtnConvertEuro.Size = new System.Drawing.Size(75, 23);
            this.BtnConvertEuro.TabIndex = 7;
            this.BtnConvertEuro.Text = "->";
            this.BtnConvertEuro.UseVisualStyleBackColor = true;
            // 
            // BtnConverDolar
            // 
            this.BtnConverDolar.Location = new System.Drawing.Point(226, 163);
            this.BtnConverDolar.Name = "BtnConverDolar";
            this.BtnConverDolar.Size = new System.Drawing.Size(75, 23);
            this.BtnConverDolar.TabIndex = 8;
            this.BtnConverDolar.Text = "->";
            this.BtnConverDolar.UseVisualStyleBackColor = true;
            this.BtnConverDolar.Click += new System.EventHandler(this.button2_Click);
            // 
            // BtnConvertPesos
            // 
            this.BtnConvertPesos.Location = new System.Drawing.Point(226, 224);
            this.BtnConvertPesos.Name = "BtnConvertPesos";
            this.BtnConvertPesos.Size = new System.Drawing.Size(75, 23);
            this.BtnConvertPesos.TabIndex = 9;
            this.BtnConvertPesos.Text = "->";
            this.BtnConvertPesos.UseVisualStyleBackColor = true;
            // 
            // BtnCotizacion
            // 
            this.BtnCotizacion.Image = global::Ejercicio_23.Properties.Resources.iconfinder_icon_114_lock_314692;
            this.BtnCotizacion.Location = new System.Drawing.Point(226, 30);
            this.BtnCotizacion.Name = "BtnCotizacion";
            this.BtnCotizacion.Size = new System.Drawing.Size(75, 23);
            this.BtnCotizacion.TabIndex = 10;
            this.BtnCotizacion.UseVisualStyleBackColor = true;
            this.BtnCotizacion.Click += new System.EventHandler(this.BtnCotizacion_Click);
            // 
            // txtEuro
            // 
            this.txtEuro.Location = new System.Drawing.Point(106, 103);
            this.txtEuro.Name = "txtEuro";
            this.txtEuro.Size = new System.Drawing.Size(100, 20);
            this.txtEuro.TabIndex = 11;
            // 
            // txtDolar
            // 
            this.txtDolar.Location = new System.Drawing.Point(106, 163);
            this.txtDolar.Name = "txtDolar";
            this.txtDolar.Size = new System.Drawing.Size(100, 20);
            this.txtDolar.TabIndex = 12;
            // 
            // txtPesos
            // 
            this.txtPesos.Location = new System.Drawing.Point(106, 224);
            this.txtPesos.Name = "txtPesos";
            this.txtPesos.Size = new System.Drawing.Size(100, 20);
            this.txtPesos.TabIndex = 13;
            // 
            // txtEuroEuro
            // 
            this.txtEuroEuro.Location = new System.Drawing.Point(323, 105);
            this.txtEuroEuro.Name = "txtEuroEuro";
            this.txtEuroEuro.Size = new System.Drawing.Size(100, 20);
            this.txtEuroEuro.TabIndex = 14;
            // 
            // txtDolarEuro
            // 
            this.txtDolarEuro.Location = new System.Drawing.Point(323, 166);
            this.txtDolarEuro.Name = "txtDolarEuro";
            this.txtDolarEuro.Size = new System.Drawing.Size(100, 20);
            this.txtDolarEuro.TabIndex = 15;
            // 
            // txtPesosEuro
            // 
            this.txtPesosEuro.Location = new System.Drawing.Point(323, 226);
            this.txtPesosEuro.Name = "txtPesosEuro";
            this.txtPesosEuro.Size = new System.Drawing.Size(100, 20);
            this.txtPesosEuro.TabIndex = 16;
            // 
            // txtEuroDolar
            // 
            this.txtEuroDolar.Location = new System.Drawing.Point(459, 104);
            this.txtEuroDolar.Name = "txtEuroDolar";
            this.txtEuroDolar.Size = new System.Drawing.Size(100, 20);
            this.txtEuroDolar.TabIndex = 17;
            // 
            // txtDolarDolar
            // 
            this.txtDolarDolar.Location = new System.Drawing.Point(459, 166);
            this.txtDolarDolar.Name = "txtDolarDolar";
            this.txtDolarDolar.Size = new System.Drawing.Size(100, 20);
            this.txtDolarDolar.TabIndex = 18;
            // 
            // txtPesosDolar
            // 
            this.txtPesosDolar.Location = new System.Drawing.Point(459, 224);
            this.txtPesosDolar.Name = "txtPesosDolar";
            this.txtPesosDolar.Size = new System.Drawing.Size(100, 20);
            this.txtPesosDolar.TabIndex = 19;
            // 
            // txtEuroPesos
            // 
            this.txtEuroPesos.Location = new System.Drawing.Point(594, 105);
            this.txtEuroPesos.Name = "txtEuroPesos";
            this.txtEuroPesos.Size = new System.Drawing.Size(100, 20);
            this.txtEuroPesos.TabIndex = 20;
            // 
            // txtDolarPesos
            // 
            this.txtDolarPesos.Location = new System.Drawing.Point(594, 166);
            this.txtDolarPesos.Name = "txtDolarPesos";
            this.txtDolarPesos.Size = new System.Drawing.Size(100, 20);
            this.txtDolarPesos.TabIndex = 21;
            // 
            // txtPesosPesos
            // 
            this.txtPesosPesos.Location = new System.Drawing.Point(594, 224);
            this.txtPesosPesos.Name = "txtPesosPesos";
            this.txtPesosPesos.Size = new System.Drawing.Size(100, 20);
            this.txtPesosPesos.TabIndex = 22;
            // 
            // txtCotizacionEuro
            // 
            this.txtCotizacionEuro.Location = new System.Drawing.Point(323, 30);
            this.txtCotizacionEuro.Name = "txtCotizacionEuro";
            this.txtCotizacionEuro.Size = new System.Drawing.Size(100, 20);
            this.txtCotizacionEuro.TabIndex = 23;
            // 
            // txtCotizacionDolar
            // 
            this.txtCotizacionDolar.Location = new System.Drawing.Point(459, 28);
            this.txtCotizacionDolar.Name = "txtCotizacionDolar";
            this.txtCotizacionDolar.Size = new System.Drawing.Size(100, 20);
            this.txtCotizacionDolar.TabIndex = 24;
            // 
            // txtCotizacionPesos
            // 
            this.txtCotizacionPesos.Location = new System.Drawing.Point(594, 28);
            this.txtCotizacionPesos.Name = "txtCotizacionPesos";
            this.txtCotizacionPesos.Size = new System.Drawing.Size(100, 20);
            this.txtCotizacionPesos.TabIndex = 25;
            // 
            // Conversor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 277);
            this.Controls.Add(this.txtCotizacionPesos);
            this.Controls.Add(this.txtCotizacionDolar);
            this.Controls.Add(this.txtCotizacionEuro);
            this.Controls.Add(this.txtPesosPesos);
            this.Controls.Add(this.txtDolarPesos);
            this.Controls.Add(this.txtEuroPesos);
            this.Controls.Add(this.txtPesosDolar);
            this.Controls.Add(this.txtDolarDolar);
            this.Controls.Add(this.txtEuroDolar);
            this.Controls.Add(this.txtPesosEuro);
            this.Controls.Add(this.txtDolarEuro);
            this.Controls.Add(this.txtEuroEuro);
            this.Controls.Add(this.txtPesos);
            this.Controls.Add(this.txtDolar);
            this.Controls.Add(this.txtEuro);
            this.Controls.Add(this.BtnCotizacion);
            this.Controls.Add(this.BtnConvertPesos);
            this.Controls.Add(this.BtnConverDolar);
            this.Controls.Add(this.BtnConvertEuro);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Conversor";
            this.Text = "Conversor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BtnConvertEuro;
        private System.Windows.Forms.Button BtnConverDolar;
        private System.Windows.Forms.Button BtnConvertPesos;
        private System.Windows.Forms.Button BtnCotizacion;
        private System.Windows.Forms.TextBox txtEuro;
        private System.Windows.Forms.TextBox txtDolar;
        private System.Windows.Forms.TextBox txtPesos;
        private System.Windows.Forms.TextBox txtEuroEuro;
        private System.Windows.Forms.TextBox txtDolarEuro;
        private System.Windows.Forms.TextBox txtPesosEuro;
        private System.Windows.Forms.TextBox txtEuroDolar;
        private System.Windows.Forms.TextBox txtDolarDolar;
        private System.Windows.Forms.TextBox txtPesosDolar;
        private System.Windows.Forms.TextBox txtEuroPesos;
        private System.Windows.Forms.TextBox txtDolarPesos;
        private System.Windows.Forms.TextBox txtPesosPesos;
        private System.Windows.Forms.TextBox txtCotizacionEuro;
        private System.Windows.Forms.TextBox txtCotizacionDolar;
        private System.Windows.Forms.TextBox txtCotizacionPesos;
    }
}

