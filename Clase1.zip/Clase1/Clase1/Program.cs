﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 1";
            int max = int.MinValue;
            int min = int.MaxValue;
            int i = 0;
            float acumulador = 0;


            for (i = 0; i < 5; i++)
            {
                string aux = Console.ReadLine();
                int valor;
                if (int.TryParse(aux, out valor))
                {
                    acumulador = acumulador + valor;
                    if(max < valor)
                    {
                        max=valor;
                    }
                    if(min > valor)
                    {
                        min=valor;
                    }
                }
            }


            Console.WriteLine("Maximo:{0,1}Minimo:{1,1}Promedio:{2,1:#,##.00}",max,min,acumulador/5);   
           
            Console.ReadLine();

        }
    }
}
