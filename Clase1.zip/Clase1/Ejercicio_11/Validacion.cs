﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    public class Validacion
    {
        public static bool Validar(int valor,int max,int min)
        {
            bool retorno = false;
            if(valor>min && valor<max)
            {
                retorno = true;
            }
            return retorno;
        }
    }
}
