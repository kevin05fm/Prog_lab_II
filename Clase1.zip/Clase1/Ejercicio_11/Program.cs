﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 11";
            Console.WriteLine("Ingrese 10 Numeros:");
            int i;
            int max = int.MinValue;
            int min = int.MaxValue;
            int acumulador = 0;

            for(i=1;i<=10;i++)
            {
                string aux = Console.ReadLine();
                int valor;
                if (int.TryParse(aux, out valor))
                {
                    if(Validacion.Validar(valor,100,-100))
                    {
                        if(valor<min)
                        {
                            min = valor;
                        }
                        if(valor>max)
                        {
                            max = valor;
                        }
                        acumulador = acumulador + valor;
                        
                        
                    }
                    else
                    {
                        Console.WriteLine("Numero fuera de parametros[-100 a 100].Ingrese otro Numero");
                        i--;
                    }
                }

            }
            Console.WriteLine("Max:{0}\nMin:{1}\nPromedio:{2}\n", max, min, acumulador / i);
            Console.ReadKey();
        }
    }
}
