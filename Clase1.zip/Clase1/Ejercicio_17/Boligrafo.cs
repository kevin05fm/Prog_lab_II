﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    public class Boligrafo
    {
        const short cantidadTintaMaxima = 100;
        private ConsoleColor color;
        private short tinta;
        /// <summary>
        /// Constructor del objeto Boligrafo
        /// </summary>
        /// <param name="tinta"></param>
        /// <param name="color"></param>
        public Boligrafo(short tinta,ConsoleColor color)
        {
            this.tinta = tinta;
            this.color = color;
        }
        public ConsoleColor GetColor()
        {
            ConsoleColor aux;
            aux = this.color;

            return aux;
        }
        public short GetTina()
        {
            short aux;
            aux = this.tinta;

            return aux;
        }
        public bool Pintar(short gasto,out string dibujo)
        {
            bool retorno = false;
            dibujo = "";
            int i;
            if(this.tinta >= gasto)
            { 
                for(i=0;i<=gasto;i++)
                {
                    SetTinta(-1);
                    dibujo=string.Format("*");
                    retorno = true;
                }
            }
            return retorno;
        }
        public void recarga()
        {
            this.tinta = cantidadTintaMaxima;
        }
        private void SetTinta(short tinta)
        {
            int i;
            for(i=0;i<=cantidadTintaMaxima;i++)
            {
                this.tinta += tinta;

                    if(this.tinta < 0)
                    {
                        this.tinta = 0;
                    }
 
            }

        }



    }
}
