﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Boligrafo boligrafoAzul = new Boligrafo(100, ConsoleColor.Blue);
            Boligrafo boligrafoRojo = new Boligrafo(50, ConsoleColor.Red);
            string variable;

           //boligrafoAzul.Pintar(20,out variable );
            Console.WriteLine("Variable:{0}", boligrafoAzul);
            Console.ReadLine();
        }
    }
}
