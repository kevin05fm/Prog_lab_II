﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 15";
            Console.WriteLine("Ingrese un Numero");
            string aux = Console.ReadLine();
            int numero1;
            Console.WriteLine("Ingrese Otro Numero");
            string aux2 = Console.ReadLine();
            int numero2;
            int resultado;
            if(int.TryParse(aux,out numero1) && int.TryParse(aux2,out numero2))
            {
                Console.WriteLine("Ingrese una el signo de la opcion:\n1.Suma[+] \n2.Restar[-]\n3.Multiplicar[*]\n4.Dividir[/]");
                string aux3 = Console.ReadLine();
                char opcion;
                if(char.TryParse(aux3,out opcion))
                {
                    switch (opcion)
                    {
                        case '+':
                            resultado =Calculadora.Calcular(numero1, numero2, '+');
                            Console.WriteLine("La Suma es:{0}", resultado);
                            Console.ReadLine();
                            break;
                        case '-':
                           resultado = Calculadora.Calcular(numero1, numero2, '-');
                            Console.WriteLine("La Resta es:{0}", resultado);
                            Console.ReadLine();
                            break;
                        case '*':
                           resultado = Calculadora.Calcular(numero1, numero2, '*');
                            Console.WriteLine("La Multiplicacion es:{0}", resultado);
                            Console.ReadLine();
                            break;
                        case '/':
                            if(Calculadora.Validar(numero2))
                            {
                              resultado = Calculadora.Calcular(numero1, numero2, '/');
                                Console.WriteLine("La Division es:{0}", resultado);
                                Console.ReadLine();
                            }
                            else
                            {
                                Console.WriteLine("No se puede dividir por cero");
                                Console.ReadLine();
                            }
                            break;
                    }

                    
                }


            }


        }
    }
}
