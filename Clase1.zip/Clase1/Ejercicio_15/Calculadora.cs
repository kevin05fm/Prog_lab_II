﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    public class Calculadora
    {
        public static int Calcular(int Numero1,int Numero2,char operacion)
        {
            int resultado = 0;
            if(operacion == '+')
            {
                resultado = Numero1 + Numero2;
            }else if(operacion == '-')
            {
                resultado = Numero1 - Numero2;
            }
            else if(operacion == '*')
            {
                resultado = Numero1 * Numero2;
            }else if(operacion=='/')
            {
                resultado = Numero1 / Numero2;
            }

            return resultado;
        }
        public static bool Validar(int Numero2)
        {
            bool resultado = false;
            if(Numero2 != 0)
            {
                resultado = true;
            }

            return resultado;
        }
    }
}
