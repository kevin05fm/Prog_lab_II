﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 4";
            Console.WriteLine("Ingrese un Numero");
            string aux = Console.ReadLine();
            int numero;
            int i;
            int acumulador = 0;
            int j;

            if(int.TryParse(aux,out numero))
            {
                for(i=1;i<numero;i++)
                {
                    for(j=1;j<i;j++)
                    {
                        if(i%j ==0)
                        {
                            acumulador = acumulador + i;
                        }
                        if (acumulador == j)
                        {

                            Console.WriteLine("Numero Perfecto:{0}", numero);
                            Console.ReadKey();

                        }
                        acumulador = 0;
                    }

                }


            }
        }
    }
}
