﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    public class CalculoDeArea
    {
        public static double CalcularCuadrado(double numeroLado)
        {
            double area;
            area = numeroLado * numeroLado;

            return area;

        }
        public static double CalcularTriangulo(double numeroBase, double numeroAltura)
        {
            double area;
            area = (numeroBase * numeroAltura) / 2;

            return area;
        }
        public static double CalcularCirculo(double numeroRadio)
        {
            double area;
            area = 3.14 * numeroRadio;

            return area;
        }
    }
}
