﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 16";
            Alumno Alumno1 = new Alumno("Daiana", "Garcia", 1);
            Alumno Alumno2 = new Alumno("Kevin", "Fernandez", 2);
            Alumno Alumno3 = new Alumno("Juana", "Perez", 3);

            Alumno1.Estudiar(4, 6);
            Alumno1.CalcularFinal();
            
            Alumno2.Estudiar(2, 7);
            Alumno2.CalcularFinal();
            
            Alumno3.Estudiar(10, 5);
            Alumno3.CalcularFinal();
            


            Console.WriteLine("{0}{1}{2}", Alumno1.Mostrar(), Alumno2.Mostrar(), Alumno3.Mostrar());
            Console.ReadLine();





        }
    }
}
