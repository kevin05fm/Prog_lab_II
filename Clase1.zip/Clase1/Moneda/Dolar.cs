﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        double cantidad;
        static double cotizRespectoDolar;

        private Dolar()
        {
            this.cantidad = 0;
            
        }
        public Dolar(double cantidad):this()
        {
             this.cantidad =cantidad;
        }
        public Dolar(double cantidad, double cotizacion):this(cantidad)
        {
            Dolar.cotizRespectoDolar=cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }
        public static void SetCotizacion(double cotizacion)
        {
            Dolar.cotizRespectoDolar = cotizacion;
        }

        #region Comversiones
        public static implicit operator Dolar(double dolar)
        {
            Dolar aux;
            aux = new Dolar(dolar);
            return aux;
        }
        public static explicit operator Euro(Dolar d)
        {
            double aux;
            aux = d.cantidad/Euro.GetCotizacion();
            
            return new Euro(aux);
        }
        public static explicit operator Pesos(Dolar d)
        {
            double aux;
            aux = d.cantidad * Pesos.GetCotizacion();

            return new Pesos(aux);
        }
        #endregion

        #region Compara
        public static bool operator !=(Dolar d , Euro e)
        {
            bool retorno = false;
           if(d.cantidad != e.GetCantidad())
            {
                retorno = true;
            }
            return retorno;

        }
        public static bool operator !=(Dolar d, Pesos p)
        {
            bool retorno = false;
            if(d.cantidad != p.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar d, Dolar d2)
        {
            bool retorno = false;
            if(d.cantidad!= d2.cantidad)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Dolar d, Euro e)
        {
            bool retorno = false;
            if(!(d != e))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Dolar d, Pesos p)
        {
            bool retorno = false;
            if (!(d != p))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Dolar d, Dolar d2)
        {
            bool retorno = false;
            if (!(d != d2))
            {
                retorno = true;
            }
            return retorno;
        }
        #endregion

        #region Operaciones
        public static Dolar operator -(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)e).GetCantidad());
            return aux;
        }
        public static Dolar operator -(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad - ((Dolar)p).GetCantidad());

            return aux;
        }
        public static Dolar operator +(Dolar d, Euro e)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)e).GetCantidad());
            return aux;
        }
        public static Dolar operator +(Dolar d, Pesos p)
        {
            Dolar aux = new Dolar(d.cantidad + ((Dolar)p).GetCantidad());

            return aux;
        }
        #endregion
    }
}
