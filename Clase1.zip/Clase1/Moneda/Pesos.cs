﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Pesos
    {
        double cantidad;
        static double cotizRespectoDolar;

        private Pesos()
        {
            this.cantidad = 0;
            Pesos.cotizRespectoDolar = 38.33;
        }
        public Pesos(double cantidad):this()
        {
            this.cantidad = cantidad;
        }
        public Pesos(double cantidad,double cotizacion):this(cantidad)
        {
            Pesos.cotizRespectoDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }
        public static void SetCotizacion(double cotizacion)
        {
            Pesos.cotizRespectoDolar = cotizacion;
        }

        #region Conversor
        public static implicit operator Pesos(double d)
        {
            Pesos aux;
            aux = new Pesos(d);
            return aux;
        }
        public static explicit operator Dolar(Pesos p)
        {
            double aux;
            aux = p.cantidad * Dolar.GetCotizacion();

            return new Dolar(aux);
        }
        public static explicit operator Euro(Pesos p)
        {
            double aux;
            aux = (p.cantidad * Dolar.GetCotizacion())/Euro.GetCotizacion();
            return new Euro(aux);
        }
        #endregion

        #region Comparadores
        public static bool operator !=(Pesos p, Dolar d)
        {
            bool retorno = false;
            if (p.cantidad != d.GetCantidad())
            {
                retorno = true;
            }
            return retorno;

        }
        public static bool operator !=(Pesos p, Euro e)
        {
            bool retorno = false;
            if (p.cantidad != e.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos p, Pesos p2)
        {
            bool retorno = false;
            if (p.cantidad != p2.cantidad)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Pesos p, Dolar d)
        {
            bool retorno = false;
            if (!(p != d))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Pesos p, Euro e)
        {
            bool retorno = false;
            if (!(p != e))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Pesos p, Pesos p2)
        {
            bool retorno = false;
            if (!(p != p2))
            {
                retorno = true;
            }
            return retorno;
        }
        #endregion

        #region Operadores
        public static Pesos operator -(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)d).GetCantidad());
            return aux;
        }
        public static Pesos operator -(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad - ((Pesos)e).GetCantidad());

            return aux;
        }
        public static Pesos operator +(Pesos p, Dolar d)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)d).GetCantidad());
            return aux;
        }
        public static Pesos operator +(Pesos p, Euro e)
        {
            Pesos aux = new Pesos(p.cantidad + ((Pesos)e).GetCantidad());

            return aux;
        }
        #endregion


    }
}
