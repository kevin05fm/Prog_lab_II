﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 2";
            string aux = Console.ReadLine();
            int numero;
            double cuadrado;
            double cubo;
            
            if(int.TryParse(aux,out numero))
            {
                if(numero >0)
                {
                    cuadrado=Math.Pow(numero,2);
                    cubo=Math.Pow(numero,3);
                    Console.WriteLine("Cuadrado:{0}\nCubo:{1}", cuadrado, cubo);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("ERROR!!.Reingresar Numero");
                }

            }
            
        }
    }
}
