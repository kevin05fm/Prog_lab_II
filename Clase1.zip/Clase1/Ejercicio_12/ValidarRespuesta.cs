﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    public class ValidarRespuesta
    {
        public static bool validaS_N(char c)
        {
            bool respuesta;
            if(c == 's')
            {
                respuesta = true;
            }
            else
            {
                respuesta = false;
            }

            return respuesta;
        }
    }
}
