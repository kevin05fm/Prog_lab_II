﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title="Ejercicio Nro 12";
            int acumulador = 0;
            bool respuesta = true;
            char letra;
             
                    
                do 
                {
                Console.WriteLine("Ingrese Numero");
                string aux = Console.ReadLine();
                int numero;
                
                if (int.TryParse(aux, out numero))
                {
                    acumulador = acumulador + numero;
                    Console.WriteLine("\nDesea continuar? [s/n]");
                     string aux2 = Console.ReadLine();
                     if (char.TryParse(aux2, out letra))
                     {
                            respuesta = ValidarRespuesta.validaS_N(letra);
                     }
                     if(!respuesta)
                     {
                            Console.WriteLine("La suma es:{0}", acumulador);
                            Console.ReadLine();
                     } 

                }
                        
                        

                }while (respuesta);
                
 

           


        }
    }
}
