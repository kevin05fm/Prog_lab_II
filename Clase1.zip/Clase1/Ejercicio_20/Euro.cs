﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Euro
    {
        double cantidad;
        static double cotizRespectoDolar;

        private Euro()
        {
            this.cantidad = 0;
            Euro.cotizRespectoDolar = 1.16;
        }
        public Euro(double cantidad):this()
        {
            this.cantidad = cantidad;
        }
        public Euro(double cantidad,double cotizacion):this(cantidad)
        {
            Euro.cotizRespectoDolar = cotizacion;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static double GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }
        #region Conversiones
        public static implicit operator Euro(double d)
        {
            Euro aux;
            aux = new Euro(d);
            return aux;
        }
        public static explicit operator Pesos(Euro p)
        {
            double aux;
            aux = p.cantidad * Pesos.GetCotizacion();

            return new Pesos(aux);
        }
        public static explicit operator Dolar(Euro e)
        {
            double aux;
            aux = e.cantidad * Dolar.GetCotizacion();

            return new Dolar(aux);
        }
        #endregion


        #region Comparaciones
        public static bool operator !=(Euro e, Dolar d)
        {
            bool retorno = false;
            if (e.cantidad != d.GetCantidad())
            {
                retorno = true;
            }
            return retorno;

        }
        public static bool operator !=(Euro e, Pesos p)
        {
            bool retorno = false;
            if (e.cantidad != p.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro e, Euro e2)
        {
            bool retorno = false;
            if (e.cantidad != e2.cantidad)
            {
                retorno = true;
            }
            return retorno;
        }
       public static bool operator ==(Euro e, Dolar d)
        {
            bool retorno = false;
            if (!(e != d))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Euro e, Pesos p)
        {
            bool retorno = false;
            if (!(e != p))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Euro e, Euro e2)
        {
            bool retorno = false;
            if (!(e != e2))
            {
                retorno = true;
            }
            return retorno;
        }
        #endregion


        #region Operaciones
        public static Euro operator -(Euro e, Dolar d)
        {
            Euro aux = new Euro(e.cantidad - ((Euro)d).GetCantidad());
            return aux;
        }
        public static Euro operator -(Euro e, Pesos p)
        {
            Euro aux = new Euro(e.cantidad - ((Euro)p).GetCantidad());

            return aux;
        }
        public static Euro operator +(Euro e, Dolar d)
        {
            Euro aux = new Euro(e.cantidad + ((Euro)d).GetCantidad());
            return aux;
        }
        public static Euro operator +(Euro e, Pesos p)
        {
            Euro aux = new Euro(e.cantidad + ((Euro)p).GetCantidad());

            return aux;
        }
        #endregion 
    }
}
