using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Cerveza : Botella
  {
    private const int medida = 330;
    private Tipo tipo;

    #region Constructores

    public Cerveza(int capacidadML, string marca, int contenidoML) : base(marca, capacidadML, contenidoML)
    {

    }
    public Cerveza(int capacidadML, string marca, Tipo tipo, int contenidoML) : base(marca, capacidadML, contenidoML)
    {
      this.tipo = tipo;
    }
    #endregion


    #region Metodos

    protected override string GenerarInforme()
    {
      StringBuilder str = new StringBuilder();

      str.Append(base.GenerarInforme() + "\n Medida:" + medida);

      return str.ToString();

    }

    public int ServirMedida(int medida)
    {
      return Cerveza.medida - medida;
    }


    public override int ServirMedida()
    {
      int aux;
      if (medida <= Contenido)
      {
        aux = ServirMedida(medida);

      }
      else
      {
        aux = Contenido--;
      }
      return aux;
    }

    #endregion

    #region Operadores

    public static implicit operator Botella.Tipo(Cerveza cerveza)
      {
      Botella.Tipo aux;
      aux = cerveza.tipo;
      return aux;
      }

    #endregion




  }
}
