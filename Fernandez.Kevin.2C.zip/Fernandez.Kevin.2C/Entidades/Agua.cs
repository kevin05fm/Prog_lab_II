using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Agua : Botella
  {
    private const int medida=400;

    #region Constructor

    public Agua(int capacidadML ,string marca , int contenidoML):base(marca,capacidadML,contenidoML)
    {

    }

    #endregion

    #region Metodos

    protected override string GenerarInforme()
    {
      StringBuilder str = new StringBuilder();

      str.Append(base.GenerarInforme() + "\n Medida:" + medida );

      return str.ToString();
    }


    public int ServirMedida(int medida)
    {
      return Agua.medida - medida;
    }


    public override int ServirMedida()
    {
      int aux;
      if(medida <= Contenido)
      {
        aux=ServirMedida(medida);

      }
      else
      {
        aux=Contenido --;
      }
      return aux;
    }
   
    #endregion

  }
}
