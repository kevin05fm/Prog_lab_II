using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Cantina
  {
    private List<Botella> botellas;
    private int espaciosTotales;
    private Cantina singleton;

    #region Constructor

    private Cantina(int espacios)
    {
      this.espaciosTotales = espacios;
      this.botellas = new List<Botella>();
    }

    #endregion

    #region Propiedads

    public List<Botella> Botellas
    {
      get
      {
        return this.botellas;
      }
    }

    #endregion

    #region Metodos

    public Cantina GetCantina(int espacios)
    {
      if(this.singleton == null)
      {
        this.singleton = new Cantina(espacios);

      }else if(this.singleton != null)
      {
        this.espaciosTotales = espacios;
      }
      return this.singleton;

    }

    #endregion

    #region Operadores

    public static bool operator +(Cantina c , Botella b)
    {
      bool resultado = false;


            return resultado;
    }

    #endregion

  }
}
