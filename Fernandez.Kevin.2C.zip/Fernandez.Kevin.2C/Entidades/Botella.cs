using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public abstract class Botella
  {
    protected int capacidadML;
    protected int contenidoML;
    protected string marca;

    #region Propiedades
    public int CapacidadLitros
    {
      get
      {
        return this.capacidadML/1000;
      }
    }
    public int Contenido
    {
      get
      {
        return this.contenidoML;
      }
      set
      {
        this.contenidoML = value;
      }
      
    }
    protected float PorcentajeContenido
    {
      get
      {
        return Contenido * CapacidadLitros / 100;
      }
    }


    #endregion

    #region Metodos

    protected Botella(string marca,int capacidadML , int contenidoML)
    {
      if(capacidadML < contenidoML)
      {
        Contenido = capacidadML;
        this.capacidadML = contenidoML;
      }
      else
      {
        this.capacidadML = capacidadML;
        Contenido = contenidoML;
      }
      this.marca = marca;

    }

    protected virtual string GenerarInforme()
    {
      StringBuilder str = new StringBuilder();

      str.AppendLine("Contenido :" + this.Contenido + "\nCapacidad:" + this.CapacidadLitros + "\n Porcentaje" + PorcentajeContenido);

      return str.ToString();
    }
    public abstract int ServirMedida();
   
    public new string ToString()
    {
      return GenerarInforme();
    }

    #endregion

    #region Enumerado
    public enum Tipo
    {
      plastico,
      Vidrio,
    }
    #endregion

  }


}
